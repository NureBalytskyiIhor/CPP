from fastapi import FastAPI, Request, Form
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.sessions import SessionMiddleware
import sqlite3
import hashlib
from fastapi import Query
import os
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
import ssl
import certifi


app = FastAPI()

app.add_middleware(SessionMiddleware, secret_key="your-secret-key")


app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5500"],  
    allow_credentials=True,                  
    allow_methods=["*"],
    allow_headers=["*"],
)


def get_db():
    conn = sqlite3.connect("brickprince.db")
    conn.row_factory = sqlite3.Row
    return conn


@app.post("/register")
async def register(
    name: str = Form(...),
    email: str = Form(...),
    password: str = Form(...)
):
    conn = get_db()
    cursor = conn.cursor()

    hashed_pw = hashlib.sha256(password.encode()).hexdigest()

    cursor.execute("SELECT id FROM users WHERE email = ?", (email,))
    if cursor.fetchone():
        conn.close()
        return JSONResponse(status_code=400, content={"error": "Користувач уже існує"})

    cursor.execute(
        "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)",
        (name, email, hashed_pw, "user")
    )
    conn.commit()
    conn.close()

    return {"message": "Реєстрація успішна"}

@app.post("/login")
async def login(request: Request, email: str = Form(...), password: str = Form(...)):
    conn = get_db()
    cursor = conn.cursor()

    hashed_pw = hashlib.sha256(password.encode()).hexdigest()

    cursor.execute("SELECT * FROM users WHERE email = ? AND password = ?", (email, hashed_pw))
    user = cursor.fetchone()
    conn.close()

    if user:
        request.session["user_id"] = user["id"]
        request.session["role"] = user["role"]
        return {"message": "Вхід успішний"}
    else:
        return JSONResponse(status_code=401, content={"error": "Неправильний email або пароль"})

@app.get("/me")
async def get_me(request: Request):
    user_id = request.session.get("user_id")
    role = request.session.get("role")

    if not user_id:
        return JSONResponse(status_code=401, content={"error": "Ви не авторизовані"})

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, email, role FROM users WHERE id = ?", (user_id,))
    user = cursor.fetchone()
    conn.close()

    if user:
        return dict(user)
    else:
        return JSONResponse(status_code=404, content={"error": "Користувача не знайдено"})

@app.delete("/me")
async def delete_me(request: Request):
    user_id = request.session.get("user_id")

    if not user_id:
        return JSONResponse(status_code=401, content={"error": "Ви не авторизовані"})

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
    conn.commit()
    conn.close()

    request.session.clear()

    return {"message": "Акаунт успішно видалено"}

@app.post("/update-profile")
async def update_profile(request: Request, name: str = Form(...), email: str = Form(...)):
    user_id = request.session.get("user_id")
    if not user_id:
        return JSONResponse(status_code=401, content={"error": "Необхідно увійти"})

    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("SELECT id FROM users WHERE email = ? AND id != ?", (email, user_id))
    if cursor.fetchone():
        conn.close()
        return JSONResponse(status_code=400, content={"error": "Цей email вже використовується"})

    cursor.execute("UPDATE users SET name = ?, email = ? WHERE id = ?", (name, email, user_id))
    conn.commit()

    cursor.execute("SELECT id, name, email, role FROM users WHERE id = ?", (user_id,))
    updated_user = cursor.fetchone()

    conn.close()

    return dict(updated_user)

@app.get("/news")
async def get_all_news():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT id, title, content, created_at FROM news ORDER BY created_at DESC")
    rows = cursor.fetchall()
    conn.close()

    return [dict(row) for row in rows]

@app.post("/news")
async def create_news(request: Request, title: str = Form(...), content: str = Form(...)):
    user_id = request.session.get("user_id")
    role = request.session.get("role")

    if not user_id or role != "admin":
        return JSONResponse(status_code=403, content={"error": "Доступ заборонено"})

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO news (title, content, author_id) VALUES (?, ?, ?)", (title, content, user_id))
    conn.commit()
    conn.close()

    return {"message": "Новину створено успішно"}


@app.put("/news/{news_id}")
async def update_news(
    request: Request,
    news_id: int,
    title: str = Form(...),
    content: str = Form(...)
):
    user_id = request.session.get("user_id")
    role = request.session.get("role")

    if not user_id or role != "admin":
        return JSONResponse(status_code=403, content={"error": "Доступ заборонено"})

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("UPDATE news SET title = ?, content = ? WHERE id = ?", (title, content, news_id))
    conn.commit()
    conn.close()

    return {"message": "Новину оновлено"}


@app.delete("/news/{news_id}")
async def delete_news(request: Request, news_id: int):
    user_id = request.session.get("user_id")
    role = request.session.get("role")

    if not user_id or role != "admin":
        return JSONResponse(status_code=403, content={"error": "Доступ заборонено"})

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM news WHERE id = ?", (news_id,))
    conn.commit()
    conn.close()

    return {"message": "Новину видалено"}


from fastapi import Query

@app.get("/feedback")
async def get_all_feedback(skip: int = 0, limit: int = 10):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT f.id, f.user_id, u.name AS author_name, f.text, f.rating, f.created_at
        FROM feedback f
        JOIN users u ON f.user_id = u.id
        ORDER BY f.created_at DESC
        LIMIT ? OFFSET ?
    """, (limit, skip))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

@app.post("/feedback")
async def create_feedback(request: Request, text: str = Form(...), rating: int = Form(...)):
    user_id = request.session.get("user_id")
    if not user_id:
        return JSONResponse(status_code=401, content={"error": "Увійдіть у систему"})

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM feedback WHERE user_id = ?", (user_id,))
    if cursor.fetchone():
        conn.close()
        return JSONResponse(status_code=400, content={"error": "Ви вже залишили відгук"})

    cursor.execute("INSERT INTO feedback (user_id, text, rating) VALUES (?, ?, ?)", (user_id, text, rating))
    conn.commit()
    conn.close()

    return {"message": "Відгук створено"}

@app.get("/feedback/{feedback_id}/likes")
def get_feedback_likes(feedback_id: int):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM likes WHERE feedback_id = ? AND is_like = 1", (feedback_id,))
    likes = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM likes WHERE feedback_id = ? AND is_like = 0", (feedback_id,))
    dislikes = cursor.fetchone()[0]
    conn.close()
    return {"likes": likes, "dislikes": dislikes}

@app.put("/feedback")
async def update_feedback(request: Request, text: str = Form(...), rating: int = Form(...)):
    user_id = request.session.get("user_id")
    if not user_id:
        return JSONResponse(status_code=401, content={"error": "Необхідно увійти"})

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("UPDATE feedback SET text = ?, rating = ?, created_at = CURRENT_TIMESTAMP WHERE user_id = ?", (text, rating, user_id))
    conn.commit()
    conn.close()

    return {"message": "Відгук оновлено"}


@app.delete("/feedback")
async def delete_feedback(request: Request):
    user_id = request.session.get("user_id")
    if not user_id:
        return JSONResponse(status_code=401, content={"error": "Необхідно увійти"})

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM feedback WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()

    return {"message": "Відгук видалено"}



@app.post("/feedback/{feedback_id}/like")
async def toggle_like(request: Request, feedback_id: int, value: str = Form(...)):
    user_id = request.session.get("user_id")
    if not user_id:
        return JSONResponse(status_code=401, content={"error": "Необхідно увійти"})

    if value not in ["like", "dislike"]:
        return JSONResponse(status_code=400, content={"error": "Недопустиме значення"})

    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("SELECT is_like FROM likes WHERE user_id = ? AND feedback_id = ?", (user_id, feedback_id))
    existing = cursor.fetchone()

    if existing:
        is_like = bool(existing[0])
        if (value == "like" and is_like) or (value == "dislike" and not is_like):
            cursor.execute("DELETE FROM likes WHERE user_id = ? AND feedback_id = ?", (user_id, feedback_id))
        else:
            cursor.execute("""
                UPDATE likes SET is_like = ? WHERE user_id = ? AND feedback_id = ?
            """, (value == "like", user_id, feedback_id))
    else:
        cursor.execute("""
            INSERT INTO likes (user_id, feedback_id, is_like) VALUES (?, ?, ?)
        """, (user_id, feedback_id, value == "like"))

    cursor.execute("SELECT COUNT(*) FROM likes WHERE feedback_id = ? AND is_like = 1", (feedback_id,))
    likes = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM likes WHERE feedback_id = ? AND is_like = 0", (feedback_id,))
    dislikes = cursor.fetchone()[0]

    conn.commit()
    conn.close()

    return {"likes": likes, "dislikes": dislikes}



@app.get("/admin/users")
async def get_all_users(request: Request):
    if request.session.get("role") != "admin":
        return JSONResponse(status_code=403, content={"error": "Доступ заборонено"})

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT id, email, role FROM users ORDER BY id")
    users = cursor.fetchall()
    conn.close()
    return [dict(u) for u in users]


@app.delete("/admin/users/{user_id}")
async def delete_user(request: Request, user_id: int):
    if request.session.get("role") != "admin":
        return JSONResponse(status_code=403, content={"error": "Доступ заборонено"})

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
    conn.commit()
    conn.close()

    return {"message": "Користувача видалено"}

@app.delete("/admin/feedback/{feedback_id}")
async def admin_delete_feedback(request: Request, feedback_id: int):
    if request.session.get("role") != "admin":
        return JSONResponse(status_code=403, content={"error": "Доступ заборонено"})

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM feedback WHERE id = ?", (feedback_id,))
    conn.commit()
    conn.close()

    return {"message": "Відгук видалено"}


ssl._create_default_https_context = lambda: ssl.create_default_context(cafile=certifi.where())

def send_game_email(to_email: str):
    message = Mail(
        from_email="ihor.balytskyi1@nure.ua",
        to_emails=to_email,
        subject="Ваш Brick Prince — гра готова!",
        html_content="""
            <h1>Дякуємо, що оформили гру Brick Prince!</h1>
            <p>Ось посилання для завантаження гри:</p>
            <a href="https://your-download-link.com">Завантажити гру</a>
        """,
    )
    try:
        sg = SendGridAPIClient(os.getenv("SENDGRID_API_KEY"))
        response = sg.send(message)
        print(f"SendGrid response status: {response.status_code}")
        return True
    except Exception as e:
        print(f"SendGrid error: {e}")
        return False


@app.post("/send-game-email")
async def send_game_email_endpoint(request: Request):
    data = await request.json()
    email = data.get("email")
    if not email:
        return JSONResponse(status_code=400, content={"error": "Email не вказано"})
    success = send_game_email(email)
    if success:
        return {"message": "Лист успішно надіслано"}
    else:
        return JSONResponse(status_code=500, content={"error": "Не вдалося надіслати лист"})