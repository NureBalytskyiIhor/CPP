document.addEventListener("DOMContentLoaded", () => {
  console.log("rofile.js loaded");

  const userData = localStorage.getItem("user");

  if (!userData) {
    alert("Користувач не авторизований");
    window.location.href = "/src/pages/auth.html";
    return;
  }

  const user = JSON.parse(userData);
  console.log("🔹 User from localStorage:", user);

  const nameSpan = document.getElementById("profile-name");
  const emailSpan = document.getElementById("profile-email");
  const editForm = document.getElementById("edit-form");
  const editBtn = document.getElementById("edit-btn");
  const cancelBtn = document.getElementById("cancel-edit");
  const newNameInput = document.getElementById("new-name");
  const newEmailInput = document.getElementById("new-email");
  const deleteBtn = document.getElementById("delete-btn");

  if (nameSpan && emailSpan) {
    nameSpan.textContent = user.name;
    emailSpan.textContent = user.email;
  }

  editForm.classList.add("hidden");

  editBtn.addEventListener("click", () => {
    editForm.classList.remove("hidden");
    newNameInput.value = user.name;
    newEmailInput.value = user.email;
  });

  cancelBtn.addEventListener("click", () => {
    editForm.classList.add("hidden");
  });

  editForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const name = newNameInput.value.trim();
    const email = newEmailInput.value.trim();

    const formData = new FormData();
    formData.append("name", name);
    formData.append("email", email);

    try {
      const res = await fetch("http://127.0.0.1:8000/update-profile", {
        method: "POST",
        body: formData,
        credentials: "include"
      });

      if (res.ok) {
        const updated = await res.json();
        localStorage.setItem("user", JSON.stringify(updated));
        nameSpan.textContent = updated.name;
        emailSpan.textContent = updated.email;
        editForm.classList.add("hidden");
        alert("Профіль оновлено");
      } else {
        const err = await res.json();
        alert("Помилка оновлення: " + (err.error || ""));
      }
    } catch (err) {
      console.error("Fetch error:", err);
      alert("Сталася помилка");
    }
  });

  deleteBtn.addEventListener("click", async () => {
    const confirmed = confirm("Ви дійсно хочете видалити акаунт?");
    if (!confirmed) return;

    const res = await fetch("http://127.0.0.1:8000/me", {
      method: "DELETE",
      credentials: "include"
    });

    if (res.ok) {
      localStorage.removeItem("user");
      alert("Акаунт видалено");
      window.location.href = "/index.html";
    } else {
      alert("Не вдалося видалити акаунт");
    }
  });


  if (user.role === "admin") {
    const container = document.getElementById("admin-panel-container");
    const adminBtn = document.createElement("button");
    adminBtn.textContent = "Адмін панель";
    adminBtn.className = "btn admin-panel-btn";
    adminBtn.id = "admin-panel-btn";

    adminBtn.addEventListener("click", () => {
      window.location.href = "/src/admin/admin.html";
    });

    container.classList.remove("hidden");
    container.appendChild(adminBtn);
  }
});
