document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("login-form");
  const registerForm = document.getElementById("register-form");
  const showLogin = document.getElementById("show-login");
  const showRegister = document.getElementById("show-register");


  showLogin.addEventListener("click", () => {
    loginForm.classList.remove("hidden");
    registerForm.classList.add("hidden");
    showLogin.classList.add("active");
    showRegister.classList.remove("active");
  });

  showRegister.addEventListener("click", () => {
    loginForm.classList.add("hidden");
    registerForm.classList.remove("hidden");
    showLogin.classList.remove("active");
    showRegister.classList.add("active");
  });

  
  registerForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const name = document.getElementById("register-name").value.trim();
    const email = document.getElementById("register-email").value.trim();
    const password = document.getElementById("register-password").value;

    if (!name || !email || !password) {
      alert("Будь ласка, заповніть усі поля");
      return;
    }

    const formData = new FormData();
    formData.append("name", name);
    formData.append("email", email);
    formData.append("password", password);

    try {
      const res = await fetch("http://127.0.0.1:8000/register", {
        method: "POST",
        body: formData,
        credentials: "include"
      });

      if (!res.ok) {
        const err = await res.json();
        alert("Помилка реєстрації: " + (err.error || res.status));
        return;
      }

      const loginRes = await fetch("http://127.0.0.1:8000/login", {
        method: "POST",
        body: new URLSearchParams({ email, password }),
        credentials: "include"
      });

      if (loginRes.ok) {
        const meRes = await fetch("http://127.0.0.1:8000/me", {
          credentials: "include"
        });
        const user = await meRes.json();
        localStorage.setItem("user", JSON.stringify(user));
        window.location.href = "/index.html";
      } else {
        alert("Не вдалося увійти після реєстрації");
      }
    } catch (err) {
      console.error(" Register error:", err);
      alert("Помилка з'єднання при реєстрації");
    }
  });

  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const email = document.getElementById("login-email").value.trim();
    const password = document.getElementById("login-password").value;

    if (!email || !password) {
      alert("Будь ласка, введіть email і пароль");
      return;
    }

    const formData = new FormData();
    formData.append("email", email);
    formData.append("password", password);

    try {
      const res = await fetch("http://127.0.0.1:8000/login", {
        method: "POST",
        body: formData,
        credentials: "include"
      });

      if (!res.ok) {
        const err = await res.json();
        alert("Помилка входу: " + (err.error || res.status));
        return;
      }

      const meRes = await fetch("http://127.0.0.1:8000/me", {
        credentials: "include"
      });
      const user = await meRes.json();
      localStorage.setItem("user", JSON.stringify(user));
      window.location.href = "/index.html";
    } catch (err) {
      console.error("Login error:", err);
      alert("Помилка з'єднання при вході");
    }
  });
});
