document.addEventListener("DOMContentLoaded", async () => {
  const newsList = document.getElementById("news-list");

  try {
    const res = await fetch("http://127.0.0.1:8000/news", {
      credentials: "include",
    });

    if (!res.ok) {
      throw new Error("Помилка завантаження новин");
    }

    const newsArray = await res.json();

    if (newsArray.length === 0) {
      newsList.innerHTML = "<p>Новини наразі відсутні.</p>";
      return;
    }

    newsArray.forEach(news => {
      const card = document.createElement("div");
      card.className = "news-card";

      const date = new Date(news.created_at).toLocaleDateString("uk-UA");

      card.innerHTML = `
        <h3 class="news-title">${news.title}</h3>
        <p class="news-date">${date}</p>
        <p class="news-content">${news.content}</p>
      `;

      newsList.appendChild(card);
    });
  } catch (err) {
    console.error(err);
    newsList.innerHTML = "<p>Сталася помилка при завантаженні новин.</p>";
  }
});
