function updateNavbarLinks() {
  const loginLink = document.querySelector(".auth-link");
  const profileLink = document.querySelector(".profile-link");
  const user = JSON.parse(localStorage.getItem("user"));

  if (loginLink && profileLink) {
    if (user) {
      loginLink.style.display = "none";
      profileLink.style.display = "inline-block";
    } else {
      loginLink.style.display = "inline-block";
      profileLink.style.display = "none";
    }
  }

  const currentPage = window.location.pathname.split("/").pop();
  document.querySelectorAll(".nav-link").forEach(link => {
    const href = link.getAttribute("href");
    if (href && href.includes(currentPage)) {
      link.classList.add("active");
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const checkNavbar = setInterval(() => {
    const ready = document.querySelector(".auth-link") && document.querySelector(".profile-link");
    if (ready) {
      updateNavbarLinks();
      clearInterval(checkNavbar);
    }
  }, 100);
});
