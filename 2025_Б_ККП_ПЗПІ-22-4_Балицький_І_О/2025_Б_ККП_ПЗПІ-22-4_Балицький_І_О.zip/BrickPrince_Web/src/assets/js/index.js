document.addEventListener("DOMContentLoaded", () => {
  const user = JSON.parse(localStorage.getItem("user"));
  const formSection = document.querySelector(".form-section");
  const orderBtn = document.querySelector(".hero .btn");
  const form = document.querySelector(".form-section form");
  const emailInput = form.querySelector('input[type="email"]');

  if (user) {
    if (formSection) formSection.style.display = "none";
  }

  if (orderBtn) {
    orderBtn.addEventListener("click", (e) => {
      e.preventDefault();
      if (!user) {
        if (formSection) {
          formSection.scrollIntoView({ behavior: "smooth" });
          emailInput.focus();
        }
      } else {
        sendGameEmail(user.email);
      }
    });
  }

  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const email = emailInput.value.trim();
      if (!validateEmail(email)) {
        alert("Будь ласка, введіть коректний email");
        emailInput.focus();
        return;
      }
      sendGameEmail(email);
    });
  }

  async function sendGameEmail(email) {
    try {
      const res = await fetch("http://127.0.0.1:8000/send-game-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
        credentials: "include",
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Помилка при відправці листа");
      }

      alert(`Лист з грою успішно надіслано на: ${email}. Перевірте вашу пошту!`);
      if (!user && formSection) {
        emailInput.value = "";
      }
    } catch (err) {
      alert(err.message);
    }
  }

  function validateEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }
});
