document.addEventListener("DOMContentLoaded", async () => {
  const feedbackList = document.getElementById("feedback-list");
  const loadMoreBtn = document.getElementById("load-more-btn");
  const createFeedbackBtn = document.getElementById("create-feedback-btn");
  const modal = document.getElementById("feedback-modal");
  const saveBtn = document.getElementById("save-feedback");
  const cancelBtn = document.getElementById("cancel-feedback");
  const feedbackText = document.getElementById("feedback-text");
  const feedbackRating = document.getElementById("feedback-rating");

  let skip = 0;
  const limit = 10;
  let allLoaded = false;
  let currentUserId = null;

  async function getCurrentUser() {
    try {
      const res = await fetch("http://127.0.0.1:8000/me", { credentials: "include" });
      if (!res.ok) return;
      const data = await res.json();
      currentUserId = data.id;
      createFeedbackBtn.style.display = "inline-block";
    } catch {
      currentUserId = null;
      createFeedbackBtn.style.display = "none";
    }
  }

  async function fetchFeedbacks() {
    if (allLoaded) return;

    const res = await fetch(`http://127.0.0.1:8000/feedback?skip=${skip}&limit=${limit}`, {
      credentials: "include"
    });
    if (!res.ok) {
      console.error("Помилка завантаження відгуків");
      return;
    }

    const feedbacks = await res.json();
    if (feedbacks.length === 0) {
      allLoaded = true;
      loadMoreBtn.style.display = "none";
      return;
    }

    for (const feedback of feedbacks) {
      const counts = await fetchLikes(feedback.id);
      renderFeedbackCard(feedback, counts);
    }

    skip += feedbacks.length;
    if (feedbacks.length < limit) {
      allLoaded = true;
      loadMoreBtn.style.display = "none";
    }
  }

  async function fetchLikes(feedbackId) {
    const res = await fetch(`http://127.0.0.1:8000/feedback/${feedbackId}/likes`);
    if (!res.ok) return { likes: 0, dislikes: 0 };
    return await res.json();
  }

  function renderFeedbackCard(feedback, counts) {
    const card = document.createElement("div");
    card.className = "feedback-card";
    if (currentUserId === feedback.user_id) {
      card.classList.add("my-feedback");
    }

    const date = new Date(feedback.created_at).toLocaleDateString("uk-UA");

    card.innerHTML = `
      <div class="feedback-header">
        <strong>${feedback.author_name}</strong>
        <span class="feedback-rating">${feedback.rating}/10</span>
      </div>
      <p class="feedback-text">${feedback.text}</p>
      <div class="feedback-footer">
        <span class="feedback-date">${date}</span>
        <div class="feedback-actions">
          <button class="like-btn" data-id="${feedback.id}" data-type="like">👍 ${counts.likes}</button>
          <button class="dislike-btn" data-id="${feedback.id}" data-type="dislike">👎 ${counts.dislikes}</button>
        </div>
      </div>
    `;

    const actions = card.querySelector(".feedback-actions");

    actions.querySelectorAll("button[data-type]").forEach(btn => {
      btn.addEventListener("click", async () => {
        const type = btn.dataset.type;
        const id = btn.dataset.id;
        const form = new FormData();
        form.append("value", type);

        const res = await fetch(`http://127.0.0.1:8000/feedback/${id}/like`, {
          method: "POST",
          body: form,
          credentials: "include"
        });

        if (res.ok) {
          const { likes, dislikes } = await res.json();
          actions.querySelector(".like-btn").textContent = `👍 ${likes}`;
          actions.querySelector(".dislike-btn").textContent = `👎 ${dislikes}`;
        }
      });
    });

    if (currentUserId === feedback.user_id) {
      const editBtn = document.createElement("button");
      editBtn.textContent = "Редагувати";
      editBtn.className = "btn edit";
      editBtn.onclick = () => openModal("edit", feedback);

      const deleteBtn = document.createElement("button");
      deleteBtn.textContent = "Видалити";
      deleteBtn.className = "btn delete";
      deleteBtn.onclick = () => deleteFeedback();

      actions.appendChild(editBtn);
      actions.appendChild(deleteBtn);
    }

    feedbackList.appendChild(card);
  }

  function openModal(mode = "create", feedback = null) {
    modal.classList.remove("hidden");
    document.getElementById("modal-title").textContent =
      mode === "edit" ? "Редагувати відгук" : "Новий відгук";
    saveBtn.dataset.mode = mode;
    saveBtn.dataset.id = feedback?.id || "";
    feedbackText.value = feedback?.text || "";
    feedbackRating.value = feedback?.rating || "";
  }

  function closeModal() {
    modal.classList.add("hidden");
    feedbackText.value = "";
    feedbackRating.value = "";
  }

  async function saveFeedback() {
    const text = feedbackText.value.trim();
    const rating = feedbackRating.value;
    const mode = saveBtn.dataset.mode;

    if (!text || !rating) {
      alert("Будь ласка, заповніть усі поля");
      return;
    }

    const formData = new FormData();
    formData.append("text", text);
    formData.append("rating", rating);

    const url = "http://127.0.0.1:8000/feedback";
    const method = mode === "edit" ? "PUT" : "POST";

    const res = await fetch(url, {
      method,
      body: formData,
      credentials: "include",
    });

    if (res.ok) {
      location.reload();
    } else {
      const data = await res.json();
      alert(data.error || "Сталася помилка");
    }
  }

  async function deleteFeedback() {
    if (!confirm("Ви впевнені, що хочете видалити відгук?")) return;

    const res = await fetch("http://127.0.0.1:8000/feedback", {
      method: "DELETE",
      credentials: "include",
    });

    if (res.ok) {
      location.reload();
    } else {
      alert("Помилка при видаленні відгуку");
    }
  }

  cancelBtn.addEventListener("click", closeModal);
  saveBtn.addEventListener("click", saveFeedback);
  createFeedbackBtn.addEventListener("click", () => openModal("create"));
  loadMoreBtn.addEventListener("click", fetchFeedbacks);

  await getCurrentUser();
  await fetchFeedbacks();
});
