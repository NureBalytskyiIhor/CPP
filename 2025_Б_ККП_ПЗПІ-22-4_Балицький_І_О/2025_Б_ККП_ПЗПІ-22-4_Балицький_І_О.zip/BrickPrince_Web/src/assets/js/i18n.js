let currentLang = 'ua';

const langBtn = document.querySelector('.lang-switch');

langBtn.addEventListener('click', () => {
  currentLang = currentLang === 'ua' ? 'en' : 'ua';
  loadLang(currentLang);
  langBtn.textContent = currentLang === 'ua' ? 'UA / EN' : 'EN / UA';
});


function loadLang(lang) {
  fetch(`src/assets/lang/${lang}.json`)
    .then(response => response.json())
    .then(translations => {
      document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (translations[key]) {
          el.textContent = translations[key];
        }
      });

      const emailInput = document.querySelector('input[type="email"]');
      if (emailInput && translations["form_email_placeholder"]) {
        emailInput.placeholder = translations["form_email_placeholder"];
      }
    })
    .catch(error => {
      console.error(`Помилка завантаження мовного файлу (${lang}):`, error);
    });
}

document.addEventListener('DOMContentLoaded', () => {
  loadLang(currentLang);
});
