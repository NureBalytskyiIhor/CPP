document.addEventListener("DOMContentLoaded", () => {
  const usersTableBody = document.querySelector("#users-table tbody");
  const searchInput = document.getElementById("search-input");
  const noUsersMsg = document.getElementById("no-users-msg");
  const backBtn = document.getElementById("back-to-dashboard");

  let users = [];

  async function loadUsers() {
    try {
      const res = await fetch("http://127.0.0.1:8000/admin/users", { credentials: "include" });
      if (!res.ok) throw new Error("Не вдалося завантажити користувачів");

      users = await res.json();
      renderUsers(users);
    } catch (err) {
      alert(err.message);
    }
  }

  function renderUsers(usersList) {
    usersTableBody.innerHTML = "";

    if (usersList.length === 0) {
      noUsersMsg.classList.remove("hidden");
      return;
    } else {
      noUsersMsg.classList.add("hidden");
    }

    usersList.forEach(user => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${user.id}</td>
        <td>${user.email}</td>
        <td>${user.role}</td>
        <td>
          ${user.role === "user" ? `<button class="btn verify-btn" data-id="${user.id}">Верифікувати</button>` : ""}
          <button class="btn delete-btn" data-id="${user.id}">Видалити</button>
        </td>
      `;
      usersTableBody.appendChild(tr);
    });
  }

  searchInput.addEventListener("input", () => {
    const query = searchInput.value.toLowerCase();
    const filtered = users.filter(u => u.email.toLowerCase().includes(query));
    renderUsers(filtered);
  });

  usersTableBody.addEventListener("click", async (e) => {
    if (e.target.classList.contains("delete-btn")) {
      const userId = e.target.dataset.id;
      if (confirm("Ви дійсно хочете видалити користувача?")) {
        try {
          const res = await fetch(`http://127.0.0.1:8000/admin/users/${userId}`, {
            method: "DELETE",
            credentials: "include"
          });
          if (!res.ok) throw new Error("Не вдалося видалити користувача");
          alert("Користувача видалено");
          loadUsers();
        } catch (err) {
          alert(err.message);
        }
      }
    }

    if (e.target.classList.contains("verify-btn")) {
    }
  });

  // Повернення на головну сторінку адмін панелі
  backBtn.addEventListener("click", () => {
    window.location.href = "/src/admin/admin.html";
  });

  loadUsers();
});
