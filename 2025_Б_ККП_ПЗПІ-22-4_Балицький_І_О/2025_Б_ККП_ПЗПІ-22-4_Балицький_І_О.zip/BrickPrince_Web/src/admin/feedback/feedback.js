document.addEventListener("DOMContentLoaded", async () => {
  const feedbackList = document.getElementById("feedback-list");
  const backBtn = document.getElementById("back-to-admin");

  backBtn.addEventListener("click", () => {
    window.location.href = "/src/admin/admin.html";
  });

  async function loadFeedbacks() {
    try {
      const res = await fetch("http://127.0.0.1:8000/feedback", { credentials: "include" });
      if (!res.ok) throw new Error("Помилка завантаження відгуків");
      const feedbacks = await res.json();
      renderFeedbacks(feedbacks);
    } catch (error) {
      feedbackList.innerHTML = `<p>${error.message}</p>`;
    }
  }

  function renderFeedbacks(feedbacks) {
    feedbackList.innerHTML = "";
    if (feedbacks.length === 0) {
      feedbackList.innerHTML = "<p>Відгуків немає.</p>";
      return;
    }

    feedbacks.forEach(fb => {
      const card = document.createElement("div");
      card.className = "feedback-card";
      card.innerHTML = `
        <p><strong>Користувач ID:</strong> ${fb.user_id}</p>
        <p><strong>Відгук:</strong> ${fb.text}</p>
        <p><strong>Рейтинг:</strong> ${fb.rating}/10</p>
        <p><strong>Дата:</strong> ${new Date(fb.created_at).toLocaleString("uk-UA")}</p>
        <button class="delete-btn" data-id="${fb.id}">Видалити</button>
      `;

      card.querySelector(".delete-btn").addEventListener("click", () => {
        if (confirm("Ви дійсно хочете видалити цей відгук?")) {
          deleteFeedback(fb.id);
        }
      });

      feedbackList.appendChild(card);
    });
  }

  async function deleteFeedback(id) {
    try {
      const res = await fetch(`http://127.0.0.1:8000/admin/feedback/${id}`, {
        method: "DELETE",
        credentials: "include"
      });
      if (!res.ok) throw new Error("Не вдалося видалити відгук");
      await loadFeedbacks();  
    } catch (error) {
      alert(error.message);
    }
  }

  await loadFeedbacks();
});
