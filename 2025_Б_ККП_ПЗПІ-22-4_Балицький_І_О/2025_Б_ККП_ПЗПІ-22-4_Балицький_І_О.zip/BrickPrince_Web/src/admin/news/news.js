document.addEventListener("DOMContentLoaded", () => {
  const newsList = document.getElementById("news-list");
  const searchInput = document.getElementById("search-input");
  const sortToggle = document.getElementById("sort-toggle");
  const addNewsBtn = document.getElementById("add-news-btn");
  const modal = document.getElementById("news-modal");
  const modalTitle = document.getElementById("modal-title");
  const titleInput = document.getElementById("news-title");
  const contentInput = document.getElementById("news-content");
  const saveBtn = document.getElementById("save-news-btn");      
  const cancelBtn = document.getElementById("cancel-news-btn");  

  let newsData = [];
  let filteredNews = [];
  let sortNewestFirst = true;
  let editNewsId = null;

    document.getElementById("back-to-admin").addEventListener("click", () => {
  window.location.href = "/src/admin/admin.html";
});

  async function fetchNews() {
    try {
      const res = await fetch("http://127.0.0.1:8000/news", { credentials: "include" });
      if (!res.ok) throw new Error("Помилка завантаження новин");
      newsData = await res.json();
      applyFilters();
    } catch (err) {
      alert(err.message);
    }
  }

  function applyFilters() {
    const searchTerm = searchInput.value.trim().toLowerCase();
    filteredNews = newsData.filter(n => n.title.toLowerCase().includes(searchTerm));
    filteredNews.sort((a, b) => {
      const dateA = new Date(a.created_at);
      const dateB = new Date(b.created_at);
      return sortNewestFirst ? dateB - dateA : dateA - dateB;
    });
    renderNews();
  }

  function renderNews() {
    newsList.innerHTML = "";
    if (filteredNews.length === 0) {
      newsList.innerHTML = "<p>Новини не знайдено.</p>";
      return;
    }

    filteredNews.forEach(n => {
      const item = document.createElement("div");
      item.className = "news-item";
      const date = new Date(n.created_at).toLocaleDateString("uk-UA");
      item.innerHTML = `
        <h3>${n.title}</h3>
        <p>${n.content}</p>
        <p class="news-date">${date}</p>
        <div class="news-actions">
          <button class="edit-btn" data-id="${n.id}">Редагувати</button>
          <button class="delete-btn" data-id="${n.id}">Видалити</button>
        </div>
      `;
      newsList.appendChild(item);
    });

    document.querySelectorAll(".edit-btn").forEach(btn => {
      btn.addEventListener("click", () => openModal("edit", btn.dataset.id));
    });

    document.querySelectorAll(".delete-btn").forEach(btn => {
      btn.addEventListener("click", () => deleteNews(btn.dataset.id));
    });
  }

  function openModal(mode, newsId = null) {
    modal.classList.remove("hidden");
    if (mode === "edit") {
      modalTitle.textContent = "Редагувати новину";
      const newsItem = newsData.find(n => n.id == newsId);
      titleInput.value = newsItem.title;
      contentInput.value = newsItem.content;
      editNewsId = newsId;
    } else {
      modalTitle.textContent = "Додати новину";
      titleInput.value = "";
      contentInput.value = "";
      editNewsId = null;
    }
  }

  function closeModal() {
    modal.classList.add("hidden");
    titleInput.value = "";
    contentInput.value = "";
    editNewsId = null;
  }

  async function saveNews() {
    const title = titleInput.value.trim();
    const content = contentInput.value.trim();

    if (!title || !content) {
      alert("Заповніть всі поля");
      return;
    }

    const formData = new FormData();
    formData.append("title", title);
    formData.append("content", content);

    try {
      let res;
      if (editNewsId) {
        res = await fetch(`http://127.0.0.1:8000/news/${editNewsId}`, {
          method: "PUT",
          body: formData,
          credentials: "include",
        });
      } else {
        res = await fetch("http://127.0.0.1:8000/news", {
          method: "POST",
          body: formData,
          credentials: "include",
        });
      }

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Помилка при збереженні");
      }

      await fetchNews();
      closeModal();
    } catch (err) {
      alert(err.message);
    }
  }

  async function deleteNews(id) {
    if (!confirm("Видалити новину?")) return;
    try {
      const res = await fetch(`http://127.0.0.1:8000/news/${id}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Помилка при видаленні");
      }
      await fetchNews();
    } catch (err) {
      alert(err.message);
    }
  }

  searchInput.addEventListener("input", applyFilters);
  sortToggle.addEventListener("click", () => {
    sortNewestFirst = !sortNewestFirst;
    sortToggle.textContent = sortNewestFirst ? "Сортувати: Новіші" : "Сортувати: Старіші";
    applyFilters();
  });

  addNewsBtn.addEventListener("click", () => openModal("add"));

  cancelBtn.addEventListener("click", closeModal);
  saveBtn.addEventListener("click", saveNews);

  fetchNews();
});
