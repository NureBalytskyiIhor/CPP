document.addEventListener("DOMContentLoaded", () => {
  const user = JSON.parse(localStorage.getItem("user"));
  if (!user || user.role !== "admin") {
    alert("Доступ дозволено лише адміністраторам");
    window.location.href = "/index.html";
    return;
  }

  document.getElementById("back-to-site").addEventListener("click", () => {
    window.location.href = "/index.html";
  });

  document.getElementById("btn-users").addEventListener("click", () => {
    window.location.href = "/src/admin/users/users.html";
  });

  document.getElementById("btn-feedback").addEventListener("click", () => {
    window.location.href = "/src/admin/feedback/feedback.html";
  });

  document.getElementById("btn-news").addEventListener("click", () => {
    window.location.href = "/src/admin/news/news.html";
  });
});
